clc;
clear;
close all

% خواندن داده‌ها و حذف داده‌های نامعتبر
data_t = readtable('AirQualityUCI.xlsx');
data = table2array(data_t(:, 3:end));
data(any(data == -200, 2), :) = [];
data = normalize(data);

% تقسیم داده‌ها به مجموعه‌های آموزش، تست و اعتبارسنجی
numSamples = size(data, 1);
numTrain = round(0.6 * numSamples);
numTest = round(0.2 * numSamples);
numVal = numSamples - numTrain - numTest; 

rng(42);
idx = randperm(numSamples);
testIdx = idx(1:numTest);
valIdx = idx(numTest+1:numTest+numVal);
trainIdx = setdiff(1:numSamples, [testIdx, valIdx]); 

trainData = data(trainIdx, :);
testData = data(testIdx, :);
valData = data(valIdx, :);

% تفکیک ورودی و خروجی
outputData = trainData(:, 8);
trainData(:, 8) = [];
inputData = trainData;

% ایجاد سیستم فازی با روش Subtractive Clustering
opt = genfisOptions('SubtractiveClustering');
fis = genfis(inputData, outputData, opt);

% تنظیمات ANFIS
trainingData = [inputData outputData];
outtest = testData(:, 8);
intest = testData;
intest(:, 8) = [];
testingData = [intest outtest];

options = anfisOptions('InitialFIS', fis);   
options.EpochNumber = 300;  % کاهش تعداد Epoch
options.InitialStepSize = 0.05;  % افزایش گام یادگیری اولیه برای همگرایی سریع‌تر
options.StepSizeDecreaseRate = 0.8;  % کاهش نرخ کاهش گام
options.ValidationData = testingData;

% آموزش مدل ANFIS
[fis, trainError, stepSize, chkFIS, chkError] = anfis(trainingData, options);

% نمایش خطاها و روند یادگیری
figure;
subplot(3, 1, 1);
plot(trainError, 'b', 'LineWidth', 2);
title('Training Error');
xlabel('Epoch');
ylabel('Error');
grid on;

subplot(3, 1, 2);
plot(chkError, 'r', 'LineWidth', 2);
title('Validation Error');
xlabel('Epoch');
ylabel('Error');
grid on;

subplot(3, 1, 3);
plot(stepSize, 'g', 'LineWidth', 2);
title('Step Size');
xlabel('Epoch');
ylabel('Value');
grid on;

% ارزیابی مدل روی داده‌های تست و آموزش
trainingOutputFis = evalfis(chkFIS, trainingData(:, 1:end-1));
testingOutputFis = evalfis(chkFIS, testingData(:, 1:end-1));

% محاسبه میانگین مربعات خطا
mseTrain0 = mean((trainingOutputFis - trainingData(:, end)).^2);
mseTest0 = mean((testingOutputFis - testingData(:, end)).^2);

% بهینه‌سازی مدل با RBF
mseTestArr = [];
mseTrainArr = [];
minErrTs = inf;
minErrTr = 0;
bestModel = [];

for i = 1:-0.01:0.05  % محدود کردن Spread برای افزایش سرعت
    X = trainingData(:, 1:end-1)';
    T = trainingData(:, end)';
    spread = i;
    net = newrbe(X, T, spread);
    
    Y_train = sim(net, X);
    mseTrain = mean((Y_train - T).^2);
    
    Y_test = sim(net, intest');
    mseTest = mean((Y_test - outtest').^2);
    
    mseTestArr = [mseTestArr mseTest];
    mseTrainArr = [mseTrainArr mseTrain];
    
    if mseTest < minErrTs
        bestModel = net;
        minErrTs = mseTest;
        minErrTr = mseTrain;
    end
end

% نمایش نمودارهای خطای RBF
figure;
subplot(2, 1, 1);
plot(mseTestArr, 'r', 'LineWidth', 2);
title('Test MSE for RBF');
xlabel('Iteration');
ylabel('MSE');
grid on;

subplot(2, 1, 2);
plot(mseTrainArr, 'b', 'LineWidth', 2);
title('Train MSE for RBF');
xlabel('Iteration');
ylabel('MSE');
grid on;

% نمایش بهترین مدل بهینه شده
disp(['Minimum Training MSE: ', num2str(minErrTr)]);
disp(['Minimum Testing MSE: ', num2str(minErrTs)]);
numCenters = size(bestModel.IW{1}, 1);  
disp(['Number of centers: ', num2str(numCenters)]);
