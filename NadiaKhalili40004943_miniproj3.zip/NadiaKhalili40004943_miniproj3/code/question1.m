clc;clear;close all;

fis = mamfis('Name', 'FuzzyController');


fis = addInput(fis, [-1 1], 'Name', 'Error');
fis = addMF(fis, 'Error', 'trapmf', [-1 -1 -0.5 0], 'Name', 'Negative');
fis = addMF(fis, 'Error', 'trimf', [-0.5 0 0.5], 'Name', 'Zero');
fis = addMF(fis, 'Error', 'trapmf', [0 0.5 1 1], 'Name', 'Positive');

fis = addInput(fis, [-1 1], 'Name', 'ChangeInError');
fis = addMF(fis, 'ChangeInError', 'trapmf', [-1 -1 -0.5 0], 'Name', 'Negative');
fis = addMF(fis, 'ChangeInError', 'trimf', [-0.5 0 0.5], 'Name', 'Zero');
fis = addMF(fis, 'ChangeInError', 'trapmf', [0 0.5 1 1], 'Name', 'Positive');

fis = addOutput(fis, [-1 1], 'Name', 'ControlAction');
fis = addMF(fis, 'ControlAction', 'trapmf', [-1 -1 -0.5 0], 'Name', 'Negative');
fis = addMF(fis, 'ControlAction', 'trimf', [-0.5 0 0.5], 'Name', 'Zero');
fis = addMF(fis, 'ControlAction', 'trapmf', [0 0.5 1 1], 'Name', 'Positive');


rules = [...
    "If Error is Negative and ChangeInError is Negative then ControlAction is Negative"; 
    "If Error is Negative and ChangeInError is Zero then ControlAction is Negative"; 
    "If Error is Negative and ChangeInError is Positive then ControlAction is Zero";
    "If Error is Zero and ChangeInError is Negative then ControlAction is Negative";
    "If Error is Zero and ChangeInError is Zero then ControlAction is Zero";
    "If Error is Zero and ChangeInError is Positive then ControlAction is Positive";
    "If Error is Positive and ChangeInError is Negative then ControlAction is Zero";
    "If Error is Positive and ChangeInError is Zero then ControlAction is Positive";
    "If Error is Positive and ChangeInError is Positive then ControlAction is Positive"];
fis = addRule(fis, rules);

% Display the FIS
disp(fis);

% Save the FIS to a file for importing in Simulink
writeFIS(fis, 'FuzzyController.fis');
disp('FuzzyController.fis has been saved.');

fis = readfis('FuzzyController.fis');
% نمایش توابع عضویت ورودی‌ها
figure;
subplot(1,2,1);
plotmf(fis, 'input', 1); % توابع عضویت ورودی 1 (Error)
title('Membership Functions for Error');
subplot(1,2,2);
plotmf(fis, 'input', 2); % توابع عضویت ورودی 2 (ChangeInError)
title('Membership Functions for ChangeInError');

% نمایش توابع عضویت خروجی
figure;
plotmf(fis, 'output', 1); % توابع عضویت خروجی (ControlAction)
title('Membership Functions for ControlAction');
% ورودی‌های مختلف
inputValues1 = [-0.8, -0.5];
inputValues2 = [0, 0];
inputValues3 = [0.7, 0.3];
inputValues4 = [-0.3, 0.5];
inputValues5 = [0.9, -0.2];

% محاسبه خروجی برای هر ورودی
output1 = evalfis(inputValues1, fis);
output2 = evalfis(inputValues2, fis);
output3 = evalfis(inputValues3, fis);
output4 = evalfis(inputValues4, fis);
output5 = evalfis(inputValues5, fis);

% نمایش خروجی‌ها
disp('Output for Input [Error = -0.8, ChangeInError = -0.5]:');
disp(output1);
disp('Output for Input [Error = 0, ChangeInError = 0]:');
disp(output2);
disp('Output for Input [Error = 0.7, ChangeInError = 0.3]:');
disp(output3);
disp('Output for Input [Error = -0.3, ChangeInError = 0.5]:');
disp(output4);
disp('Output for Input [Error = 0.9, ChangeInError = -0.2]:');
disp(output5);


