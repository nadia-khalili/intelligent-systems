% Create Fuzzy Inference System
fis = mamfis('Name', 'ParkingController');

% Add Input: x (Distance to target position)
fis = addInput(fis, [-10, 10], 'Name', 'x');
fis = addMF(fis, 'x', 'trimf', [-10, -5, 0], 'Name', 'Negative');
fis = addMF(fis, 'x', 'trimf', [-5, 0, 5], 'Name', 'Zero');
fis = addMF(fis, 'x', 'trimf', [0, 5, 10], 'Name', 'Positive');

% Add Input: phi (Orientation angle)
fis = addInput(fis, [0, 180], 'Name', 'phi');
fis = addMF(fis, 'phi', 'trimf', [0, 45, 90], 'Name', 'Small');
fis = addMF(fis, 'phi', 'trimf', [45, 90, 135], 'Name', 'Medium');
fis = addMF(fis, 'phi', 'trimf', [90, 135, 180], 'Name', 'Large');

% Add Output: theta (Steering angle)
fis = addOutput(fis, [-45, 45], 'Name', 'theta');
fis = addMF(fis, 'theta', 'trimf', [-45, -30, 0], 'Name', 'Left');
fis = addMF(fis, 'theta', 'trimf', [-15, 0, 15], 'Name', 'Straight');
fis = addMF(fis, 'theta', 'trimf', [0, 30, 45], 'Name', 'Right');

% Define Rule Base
rules = [...
    "x==Negative & phi==Small => theta=Right (1)"; ...
    "x==Negative & phi==Medium => theta=Straight (1)"; ...
    "x==Negative & phi==Large => theta=Left (1)"; ...
    "x==Zero & phi==Small => theta=Straight (1)"; ...
    "x==Zero & phi==Medium => theta=Left (1)"; ...
    "x==Zero & phi==Large => theta=Left (1)"; ...
    "x==Positive & phi==Small => theta=Left (1)"; ...
    "x==Positive & phi==Medium => theta=Straight (1)"; ...
    "x==Positive & phi==Large => theta=Right (1)"];

fis = addRule(fis, rules);

% Display the FIS structure
disp(fis);

% Plot Membership Functions
figure;
subplot(3, 1, 1); plotmf(fis, 'input', 1); title('Membership Functions for x');
subplot(3, 1, 2); plotmf(fis, 'input', 2); title('Membership Functions for phi');
subplot(3, 1, 3); plotmf(fis, 'output', 1); title('Membership Functions for theta');

% Save FIS to file
writeFIS(fis, 'ParkingControllerFIS');
disp('Fuzzy Inference System saved as ParkingControllerFIS.fis');
