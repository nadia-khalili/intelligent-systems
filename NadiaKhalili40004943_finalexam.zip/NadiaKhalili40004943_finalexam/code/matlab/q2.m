% Generate random input data
x = 2 * rand(1000, 1) - 1;  % Random values in the range [-1, 1]
y = 2 * rand(1000, 1) - 1;  % Random values in the range [-1, 1]

% Define the output z (e.g., a custom function of x and y, or use random values)
z = sin(pi * x) .* cos(pi * y);

% Combine inputs and output into a matrix
data = [x, y, z];

% Save the data to a .mat file for ANFIS GUI
save('anfis_data.mat', 'data');

% Save the data to a .dat file
writematrix(data, 'anfis_data.dat', 'Delimiter', '\t');
