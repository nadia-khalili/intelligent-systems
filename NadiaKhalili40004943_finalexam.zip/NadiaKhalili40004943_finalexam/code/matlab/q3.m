clc;clear;close all;
data = importdata("evaporator.dat");

plot(data);
save('evaporator_data.mat', 'data');