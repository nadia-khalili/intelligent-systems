% Define the system
s = tf('s');
T = 1 / ((s+1)^2);

% Ziegler-Nichols PID
Kp = 2.4;
Ti = 1;
Td = 0.25;
C_zn = pid(Kp, Kp/Ti, Kp*Td);

% MATLAB-tuned PID
C_matlab = pidtune(T, 'pid');

% Step response comparison
figure;
step(feedback(C_zn*T, 1), 'r', feedback(C_matlab*T, 1), 'b');
legend('Ziegler-Nichols PID', 'MATLAB-Tuned PID');
title('Step Response Comparison');